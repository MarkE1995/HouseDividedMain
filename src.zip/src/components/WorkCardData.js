import Football from '../assets/Tier-List-Football.jpg';

const ProjectCardData = [
    {
        imgsrc: Football,
        title: 'NFL Tier List',
        text: "Our Rankings of NFL teams",
        view: 'https://tiermaker.com/list/sports/nfl-teams-2022-commanders-updated-18028/3556622'
    },
    
]
  export default ProjectCardData;