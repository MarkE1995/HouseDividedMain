import FootballPlaylist from '../assets/football.jpg';
import Gaming from '../assets/game-controller.jpg'
import Movies from '../assets/Camera.jpg'

const ProjectCardData = [
    {
        imgsrc: FootballPlaylist,
        title: 'Football',
        text: "Let's talk Football!",
        view: ''
    },
    
    {
        imgsrc: Gaming,
        title: 'Gaming',
        text: "We love our video games!",
        view: ''
    },

    {
        imgsrc: Movies,
        title: 'Movies',
        text: "Our thoughts on films both classic and new!",
        view: ''
    },
]
  export default ProjectCardData;